package com.nineleaps.ecommerce.supplierservice.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.nineleaps.ecommerce.supplierservice.exception.SupplierNotFoundException;
import com.nineleaps.ecommerce.supplierservice.model.Items;
import com.nineleaps.ecommerce.supplierservice.model.Supplier;
import com.nineleaps.ecommerce.supplierservice.model.SupplierConsumer;

@Service
public class KafkaRecieverService {

	private static final Logger LOGGER = LoggerFactory.getLogger(KafkaRecieverService.class);

	@Autowired
	private JavaMailSender javaMailSender;

	@Autowired
	private SupplierService supplierService;

	
	@Payload
	@KafkaListener(topics = "${spring.kafka.template.default-topic}", groupId = "${spring.kafka.consumer.group-id}")
	public void recieveData(SupplierConsumer supplier) throws SupplierNotFoundException {
		LOGGER.info("Product ID: " + supplier.toString() + " recieved");
		LOGGER.info("Supplier Data Consumed from Kafka Broker: " + supplier.toString() + " recieved");
		try {
			for (Items item : supplier.getItems()) {
				Supplier suppllierObject = null;
				try
				{
					suppllierObject = supplierService.getSupplierByProductId(item.getProductId());
					
					LOGGER.info("Supplier Email id: "+suppllierObject.getSupplierEmail());
					
				} catch (SupplierNotFoundException e) {
					LOGGER.error("Get Supplier by product failed");
				}
				SimpleMailMessage msg = new SimpleMailMessage();
				msg.setTo(suppllierObject.getSupplierEmail());
				msg.setSubject("Order Notification Mail");
				msg.setText(item.getQuantity() + " orders has been recived for product ID " + item.getProductId()
						+ " And Order Id is " + supplier.getOrderId());
				
				javaMailSender.send(msg);
				
				LOGGER.info("Email Notification sent for: "+suppllierObject.getSupplierEmail());
			}
//			supplier.getItems().stream().filter(f -> f != null).map(item -> {
//
//				Supplier emaild = null;
//				try {
//					emaild = supplierService.getSupplierByProductId(item.getProductId());
//				} catch (SupplierNotFoundException e) {
//					LOGGER.error("Get Supplier by product failed");
//				}
//
//				SimpleMailMessage msg = new SimpleMailMessage();
//				msg.setTo(emaild.getSupplierEmail());
//				msg.setSubject("Order Notification Mail");
//				msg.setText(item.getQuantity() + " orders has been recived for product ID " + item.getProductId()
//						+ " And Order Id is " + supplier.getOrderId());
//				javaMailSender.send(msg);
//
//				return item;
//			});
			LOGGER.info("Email Notification sent Successfully");
		} catch (Exception e) {
			LOGGER.error("Email Notification failed");
		}
	}
	
	/*@KafkaListener(topics = "${spring.kafka.template.default-topic}", groupId = "${spring.kafka.consumer.group-id}")
	public void recieveData(SupplierConsumer supplier) throws SupplierNotFoundException {

		LOGGER.info("Product ID: " + supplier.toString() + " recieved");
		LOGGER.info("Supplier Data Consumed from Kafka Broker: " + supplier.toString() + " recieved");
		
		try {
			for (int i = 0; i < supplier.getItems().size(); i++) {
				System.out.println("product id=::"+supplier.getItems().get(i).getProductId());
				Supplier emaild = supplierService.getSupplierByProductId(supplier.getItems().get(i).getProductId());
				LOGGER.info("Email Id: "+emaild.getSupplierEmail());
				SimpleMailMessage msg = new SimpleMailMessage();
				msg.setTo(emaild.getSupplierEmail());
				msg.setSubject("Order Notification Mail");
				msg.setText(supplier.getItems().get(i).getQuantity()+" orders has been recived for product ID "+supplier.getItems().get(i).getProductId()+" And Order Id is "+supplier.getOrderId());
				javaMailSender.send(msg);
				LOGGER.info("Email Notification sent Successfully");
			} 
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
*/
	

}
