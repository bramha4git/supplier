package com.nineleaps.ecommerce.shippingservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@SpringBootConfiguration
class ShippingServiceApplicationTests {

	@Test
	public void contextLoads() {
	}

}
